# PulseEffectsToggleAddon
Kodi Addon to toggle PulesEffects presets
